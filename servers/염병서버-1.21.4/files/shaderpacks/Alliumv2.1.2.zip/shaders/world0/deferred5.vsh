#version 130

#define VERTEX_SHADER
#define OVERWORLD
#define DEFERRED5

#include "/program/deferred5.glsl"