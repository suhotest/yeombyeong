#version 130

#define FRAGMENT_SHADER
#define OVERWORLD
#define DEFERRED5

#include "/program/deferred5.glsl"