#version 130

#define FRAGMENT_SHADER
#define NETHER
#define DEFERRED01

#include "/program/deferred1.glsl"